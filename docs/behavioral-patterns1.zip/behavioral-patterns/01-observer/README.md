# Mẫu 1: Observer Pattern — Thông báo email bất đồng bộ

> Bản tiểu luận đầy đủ: [BAO_CAO_BEHAVIORAL_PATTERNS.md](../BAO_CAO_BEHAVIORAL_PATTERNS.md). Code backend đầy đủ và phân tích: [MA_NGUON_VA_PHAN_TICH.md](MA_NGUON_VA_PHAN_TICH.md). Demo chạy độc lập nằm trong thư mục `code-demo`.

**Trạng thái: đã có trong code.**

## Bài toán thực tế

Sau khi đặt lịch thành công, hệ thống cần gửi email xác nhận cho bệnh nhân. Nếu gọi SMTP đồng bộ ngay trong luồng đặt lịch, mạng chậm hoặc máy chủ mail quá tải sẽ kéo dài thời gian phản hồi. Đồng thời, email không nên được gửi cho một lịch hẹn bị rollback.

## Vị trí áp dụng và vai trò

Các đường dẫn dưới đây nằm trong `backend/src/main/java/com/datlichkhambenh/backend`.

| Vai trò | Thành phần thực tế | Trách nhiệm |
| --- | --- | --- |
| Client nghiệp vụ | [BookingServiceImpl](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/BookingServiceImpl.java) | Tạo lịch trong `@Transactional`, gọi `sendBookingConfirmation(...)` |
| Bên khởi phát thông báo | [AsyncEmailNotificationServiceImpl](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/AsyncEmailNotificationServiceImpl.java) | Chụp dữ liệu email và gọi `eventPublisher.publishEvent(...)` |
| Subject / cơ chế phân phối sự kiện | `ApplicationEventPublisher` của Spring | Phân phối sự kiện cho listener đã đăng ký |
| Event | [EmailNotificationRequestedEvent](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailNotificationRequestedEvent.java) | Mang `EmailNotificationMessage` |
| Observer / Listener | [EmailQueuePublisher](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailQueuePublisher.java) | Nhận sự kiện sau commit rồi chuyển message sang RabbitMQ |
| Consumer của message broker | [EmailQueueConsumer](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailQueueConsumer.java) | Nhận message từ queue và gửi email qua `JavaMailSender` |

Observer nằm trực tiếp ở đoạn Spring event → transactional listener. RabbitMQ → consumer là chặng truyền thông điệp tiếp theo; consumer không trực tiếp lắng nghe Spring event.

## Giải pháp và luồng hoạt động

1. `BookingServiceImpl.createBooking(...)` lưu lịch hẹn, cập nhật slot và gọi dịch vụ thông báo trong transaction.
2. `AsyncEmailNotificationServiceImpl` tạo message loại `BOOKING_CONFIRMED`, sau đó phát `EmailNotificationRequestedEvent`.
3. `EmailQueuePublisher.publishAfterCommit(...)` được đăng ký bằng `@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)`; transaction rollback thì listener này không được thực thi cho sự kiện đó.
4. Sau commit, `@Async` cho phép listener đẩy message trên executor riêng qua `RabbitTemplate.convertAndSend(...)`.
5. RabbitMQ định tuyến từ exchange `clinic.email.exchange`, routing key `clinic.email.send` đến queue `clinic.email.queue`.
6. `EmailQueueConsumer.consume(...)` nhận message bằng `@RabbitListener`, dựng nội dung rồi gửi qua SMTP. Request đặt lịch không phải đợi SMTP hoàn thành.

```java
// AsyncEmailNotificationServiceImpl
eventPublisher.publishEvent(new EmailNotificationRequestedEvent(message));

// EmailQueuePublisher
@Async
@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
public void publishAfterCommit(EmailNotificationRequestedEvent event) {
    // try/catch và logging có trong code thực tế
    rabbitTemplate.convertAndSend(exchange, routingKey, event.message());
}

// EmailQueueConsumer
@RabbitListener(queues = "${app.messaging.email-queue}")
public void consume(EmailNotificationMessage notification) {
    // Tạo SimpleMailMessage từ notification, sau đó gọi mailSender.send(...)
}
```

Đoạn trích đã lược bỏ phần dựng mail và xử lý log để tập trung vào mẫu. Cấu hình hỗ trợ nằm tại [AsyncConfig](../../../backend/src/main/java/com/datlichkhambenh/backend/config/AsyncConfig.java), [RabbitMqConfig](../../../backend/src/main/java/com/datlichkhambenh/backend/config/RabbitMqConfig.java) và [application.yml](../../../backend/src/main/resources/application.yml).

## Lợi ích

- Giảm phụ thuộc giữa nghiệp vụ đặt lịch và cách gửi email; bên đặt lịch chỉ gọi hợp đồng thông báo.
- Giảm thời gian chờ của bệnh nhân vì gửi SMTP nằm ở consumer riêng.
- Chỉ xếp email sau khi database commit, tránh gửi xác nhận cho giao dịch bị rollback.
- Có thể bổ sung listener cho sự kiện mà không phải thêm xử lý SMTP vào nghiệp vụ đặt lịch.

## Giới hạn và hướng cải tiến

- Việc tạo message và phát event vẫn nằm trong luồng gọi; `@Async` hiện nằm ở listener. Không nên mô tả toàn bộ dịch vụ phát event là chạy nền.
- `@TransactionalEventListener` không bật `fallbackExecution`; gọi ngoài transaction sẽ không kích hoạt listener này.
- Nếu đẩy RabbitMQ thất bại, publisher hiện chỉ ghi log. Vẫn có khoảng trống giữa database commit và publish; chưa có transactional outbox để bảo đảm chuyển giao sự kiện.
- Queue được khai báo durable, nhưng điều đó không bảo đảm email luôn được gửi thành công. Cấu hình hiện có `default-requeue-rejected: false`; chưa thấy retry/DLQ hoặc chống gửi trùng trong luồng này.
- Có hàm tạo thông báo nhắc lịch và hủy lịch; riêng việc có hàm nhắc lịch không đồng nghĩa đã có bộ lập lịch tự động.

Hướng cải tiến: transactional outbox, publisher confirms, retry có giới hạn kèm DLQ và khóa chống trùng. Đây là đề xuất, chưa phải phần đã triển khai.

## Sơ đồ

[Mở Observer.drawio](Observer.drawio): trang **Thành phần** mô tả vai trò và trang **Luồng xử lý** mô tả transaction, xử lý nền, RabbitMQ và SMTP.
