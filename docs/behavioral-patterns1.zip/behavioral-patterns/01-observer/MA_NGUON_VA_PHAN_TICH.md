# PHỤ LỤC MÃ NGUỒN VÀ PHÂN TÍCH — OBSERVER

Các lớp dưới đây được chép nguyên văn từ backend để đối chiếu khi viết và bảo vệ tiểu luận. Chúng phụ thuộc Spring, Lombok, entity và cấu hình của dự án; không phải các file chạy độc lập. Demo độc lập nằm trong [code-demo/ObserverDemo.java](code-demo/ObserverDemo.java).

## 1. Hợp đồng dịch vụ thông báo

Nghiệp vụ gọi ba nhu cầu thông báo qua interface. Interface không quyết định công nghệ SMTP hay queue.

Nguồn: [AsyncEmailNotificationService.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/AsyncEmailNotificationService.java).

```java
package com.datlichkhambenh.backend.service;

import com.datlichkhambenh.backend.entity.Appointment;

public interface AsyncEmailNotificationService {
    void sendBookingConfirmation(Appointment appointment);
    void sendAppointmentReminder(Appointment appointment);
    void sendCancellationNotice(Appointment appointment);
}
```

## 2. Dữ liệu message

Record chứa các giá trị cần để dựng email. Dữ liệu được chụp tại thời điểm phát yêu cầu thay vì đưa nguyên entity JPA vào consumer.

Nguồn: [EmailNotificationMessage.java](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailNotificationMessage.java).

```java
package com.datlichkhambenh.backend.messaging;

public record EmailNotificationMessage(
        String type,
        String recipientEmail,
        String patientName,
        String bookingCode,
        String doctorName,
        String workDate,
        String startTime,
        String endTime,
        String price
) {
}
```

## 3. Application event

Event là đối tượng được Spring phân phối trong ứng dụng; message bên trong là dữ liệu được gửi qua RabbitMQ.

Nguồn: [EmailNotificationRequestedEvent.java](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailNotificationRequestedEvent.java).

```java
package com.datlichkhambenh.backend.messaging;

public record EmailNotificationRequestedEvent(EmailNotificationMessage message) {
}
```

## 4. Thành phần khởi phát

Ba phương thức cùng quy về publish. Dòng publishEvent là điểm chuyển từ yêu cầu nghiệp vụ sang cơ chế Observer. Không có @Async trên các phương thức này; việc tạo message vẫn chạy trong luồng gọi.

Nguồn: [AsyncEmailNotificationServiceImpl.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/AsyncEmailNotificationServiceImpl.java).

```java
package com.datlichkhambenh.backend.service.impl;

import com.datlichkhambenh.backend.entity.Appointment;
import com.datlichkhambenh.backend.messaging.EmailNotificationMessage;
import com.datlichkhambenh.backend.messaging.EmailNotificationRequestedEvent;
import com.datlichkhambenh.backend.service.AsyncEmailNotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AsyncEmailNotificationServiceImpl implements AsyncEmailNotificationService {
    private final ApplicationEventPublisher eventPublisher;

    @Override
    public void sendBookingConfirmation(Appointment appointment) {
        publish("BOOKING_CONFIRMED", appointment);
    }

    @Override
    public void sendAppointmentReminder(Appointment appointment) {
        publish("APPOINTMENT_REMINDER", appointment);
    }

    @Override
    public void sendCancellationNotice(Appointment appointment) {
        publish("BOOKING_CANCELLED", appointment);
    }

    private void publish(String type, Appointment appointment) {
        EmailNotificationMessage message = new EmailNotificationMessage(
                type,
                appointment.getPatient().getUser().getEmail(),
                appointment.getPatient().getFullName(),
                appointment.getBookingCode(),
                appointment.getDoctor().getFullName(),
                appointment.getSchedule().getWorkDate().toString(),
                appointment.getSchedule().getStartTime().toString(),
                appointment.getSchedule().getEndTime().toString(),
                appointment.getPrice() == null ? null : appointment.getPrice().toPlainString()
        );
        eventPublisher.publishEvent(new EmailNotificationRequestedEvent(message));
    }
}
```

## 5. Transactional observer

AFTER_COMMIT quy định thời điểm; @Async tách thực thi phần thân listener. Catch hiện chỉ ghi log, không lưu tác vụ để gửi lại.

Nguồn: [EmailQueuePublisher.java](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailQueuePublisher.java).

```java
package com.datlichkhambenh.backend.messaging;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailQueuePublisher {
    private final RabbitTemplate rabbitTemplate;

    @Value("${app.messaging.email-exchange}")
    private String exchange;

    @Value("${app.messaging.email-routing-key}")
    private String routingKey;

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void publishAfterCommit(EmailNotificationRequestedEvent event) {
        try {
            rabbitTemplate.convertAndSend(exchange, routingKey, event.message());
            log.info("Queued email notification for booking {}", event.message().bookingCode());
        } catch (Exception ex) {
            log.error("Cannot queue email notification for booking {}: {}",
                    event.message().bookingCode(), ex.getMessage());
        }
    }
}
```

## 6. Consumer và SMTP

@RabbitListener nhận message từ broker. subject/body xử lý các loại thông báo; mailSender.send thực hiện I/O gửi mail. Đây là chặng sau observer Spring.

Nguồn: [EmailQueueConsumer.java](../../../backend/src/main/java/com/datlichkhambenh/backend/messaging/EmailQueueConsumer.java).

```java
package com.datlichkhambenh.backend.messaging;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmailQueueConsumer {
    private final JavaMailSender mailSender;

    @RabbitListener(queues = "${app.messaging.email-queue}")
    public void consume(EmailNotificationMessage notification) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(notification.recipientEmail());
        message.setSubject(subject(notification));
        message.setText(body(notification));
        mailSender.send(message);
        log.info("Sent {} email for booking {}", notification.type(), notification.bookingCode());
    }

    private String subject(EmailNotificationMessage notification) {
        return switch (notification.type()) {
            case "BOOKING_CANCELLED" -> "Thông báo hủy lịch khám - Mã: " + notification.bookingCode();
            case "APPOINTMENT_REMINDER" -> "Nhắc lịch khám - Mã: " + notification.bookingCode();
            default -> "Xác nhận đặt lịch khám - Mã: " + notification.bookingCode();
        };
    }

    private String body(EmailNotificationMessage n) {
        if ("BOOKING_CANCELLED".equals(n.type())) {
            return "Kính gửi %s,\n\nLịch khám mã %s đã được hủy thành công."
                    .formatted(n.patientName(), n.bookingCode());
        }
        String prefix = "APPOINTMENT_REMINDER".equals(n.type())
                ? "Đây là thông báo nhắc lịch khám của bạn."
                : "Bạn đã đặt lịch khám thành công.";
        return ("Kính gửi %s,\n\n%s\nMã đặt chỗ: %s\nBác sĩ: %s\nNgày khám: %s\n"
                + "Thời gian: %s - %s\nPhí khám: %s VNĐ")
                .formatted(n.patientName(), prefix, n.bookingCode(), n.doctorName(), n.workDate(),
                        n.startTime(), n.endTime(), n.price());
    }
}
```

## 7. Cấu hình broker

Queue và direct exchange được khai báo durable, binding nối bằng routing key. JSON converter chuyển đổi dữ liệu message giữa hai phía.

Nguồn: [RabbitMqConfig.java](../../../backend/src/main/java/com/datlichkhambenh/backend/config/RabbitMqConfig.java).

```java
package com.datlichkhambenh.backend.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMqConfig {
    @Bean
    Queue emailQueue(@Value("${app.messaging.email-queue}") String queueName) {
        return new Queue(queueName, true);
    }

    @Bean
    DirectExchange emailExchange(@Value("${app.messaging.email-exchange}") String exchangeName) {
        return new DirectExchange(exchangeName, true, false);
    }

    @Bean
    Binding emailBinding(Queue emailQueue, DirectExchange emailExchange,
                         @Value("${app.messaging.email-routing-key}") String routingKey) {
        return BindingBuilder.bind(emailQueue).to(emailExchange).with(routingKey);
    }

    @Bean
    Jackson2JsonMessageConverter rabbitMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory,
                                  Jackson2JsonMessageConverter rabbitMessageConverter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(rabbitMessageConverter);
        return template;
    }
}
```

## 8. Executor

Cấu hình tạo pool 4 core threads, tối đa 16 và queue capacity 100. Pool có giới hạn nên không được giả định nhận tải vô hạn.

Nguồn: [AsyncConfig.java](../../../backend/src/main/java/com/datlichkhambenh/backend/config/AsyncConfig.java).

```java
package com.datlichkhambenh.backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * AsyncConfig — Cấu hình ThreadPool cho @Async.
 *
 * Dùng bởi AsyncEmailNotificationService để gửi email
 * xác nhận / nhắc lịch mà không block luồng đặt lịch.
 *
 * Thread pool tách biệt với default executor để tránh
 * ảnh hưởng đến các task async khác trong hệ thống.
 */
@Configuration
public class AsyncConfig implements AsyncConfigurer {

    @Bean(name = "emailTaskExecutor")
    public Executor emailTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(16);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("email-async-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();
        return executor;
    }
}
```

## 9. Tích hợp vào nghiệp vụ đặt lịch

Toàn bộ phương thức createBooking được trích dưới đây để thấy rõ transaction, khóa slot, lưu dữ liệu, xóa cache và phát yêu cầu mail. Cơ chế khóa giải quyết tranh chấp đặt lịch, không phải là thành phần Observer.

Nguồn: [BookingServiceImpl.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/BookingServiceImpl.java). Trích đoạn, không phải lớp Java độc lập.

```java
    @Override
    @Transactional
    public AppointmentDto createBooking(Long patientUserId, CreateBookingDto request) {
        // 1. Pessimistic Write Lock trên bản ghi Schedule để tránh Race Condition khi 2 bệnh nhân đặt cùng 1 slot
        Schedule schedule = scheduleRepository.findByIdForUpdate(request.getScheduleId())
                .orElseThrow(() -> new ResourceNotFoundException("Ca khám (Schedule) không tồn tại"));

        // 2. Kiểm tra slot còn khả dụng hay không
        if (!Boolean.TRUE.equals(schedule.getIsAvailable())) {
            throw new BookingConflictException("Ca khám này đã được đặt bởi người khác hoặc không còn khả dụng");
        }
        if (appointmentRepository.existsByScheduleId(schedule.getId())) {
            throw new BookingConflictException("Ca khám này đã có lịch hẹn");
        }

        LocalDateTime slotTime = LocalDateTime.of(schedule.getWorkDate(), schedule.getStartTime());
        if (!slotTime.isAfter(LocalDateTime.now())) {
            throw new AppException("Không thể đặt ca khám đã qua");
        }

        Patient patient = patientRepository.findById(patientUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Hồ sơ bệnh nhân không tồn tại"));

        Doctor doctor = schedule.getDoctor();
        if (doctor == null) {
            throw new ResourceNotFoundException("Bác sĩ phụ trách ca khám không tồn tại");
        }
        if (!Boolean.TRUE.equals(doctor.getIsApproved()) || !Boolean.TRUE.equals(doctor.getUser().getIsActive())) {
            throw new AppException("Bác sĩ hiện không nhận lịch khám");
        }

        // 3. Tạo Appointment mới với booking_code ngẫu nhiên
        String bookingCode = "BK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        Appointment appointment = Appointment.builder()
                .bookingCode(bookingCode)
                .patient(patient)
                .doctor(doctor)
                .schedule(schedule)
                .symptoms(request.getSymptoms())
                .status("CONFIRMED")
                .price(doctor.getConsultationFee())
                .build();

        Appointment savedAppointment = appointmentRepository.save(appointment);

        // 4. Cập nhật trạng thái slot thành không khả dụng
        schedule.setIsAvailable(false);
        scheduleRepository.save(schedule);

        // 5. Invalidate slot cache trong Redis
        redisCacheService.evictSlotCache(doctor.getUserId(), schedule.getWorkDate());

        // 6. Trigger sự kiện gửi mail bất đồng bộ (Async task, KHÔNG block response)
        try {
            emailNotificationService.sendBookingConfirmation(savedAppointment);
        } catch (Exception e) {
            log.error("Lỗi khi trigger gửi mail xác nhận đặt lịch: {}", e.getMessage());
        }

        return mapToDto(savedAppointment);
    }
```

## 10. Các cấu hình liên quan

Chỉ trích các khóa messaging cần cho phân tích; không sao chép thông tin kết nối hoặc giá trị bảo mật.

```yaml
spring:
  rabbitmq:
    listener:
      simple:
        default-requeue-rejected: false
app:
  messaging:
    email-exchange: clinic.email.exchange
    email-queue: clinic.email.queue
    email-routing-key: clinic.email.send
```

Không tự động suy ra retry hoặc DLQ từ cấu hình này. Nếu cần bảo đảm phục hồi mail lỗi, phải bổ sung thiết kế và kiểm chứng riêng.
