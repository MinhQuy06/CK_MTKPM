import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Vi du Java doc lap de quan sat co che Observer.
 * Khong thay the Spring transaction, RabbitMQ hay SMTP cua backend.
 */
public class ObserverDemo {
    record BookingConfirmed(String bookingCode, String email) { }

    interface BookingObserver {
        void update(BookingConfirmed event);
    }

    static class BookingSubject {
        private final List<BookingObserver> observers = new ArrayList<>();

        void subscribe(BookingObserver observer) {
            observers.add(observer);
        }

        void unsubscribe(BookingObserver observer) {
            observers.remove(observer);
        }

        void notifyObservers(BookingConfirmed event) {
            for (BookingObserver observer : List.copyOf(observers)) {
                observer.update(event);
            }
        }
    }

    static class EmailObserver implements BookingObserver {
        private final List<CompletableFuture<Void>> pending = new ArrayList<>();
        private final List<String> delivered = new ArrayList<>();

        public void update(BookingConfirmed event) {
            pending.add(CompletableFuture.runAsync(() -> {
                // Mo phong xu ly nen; khong ket noi mail that.
                synchronized (delivered) {
                    delivered.add(event.bookingCode());
                }
                System.out.println("[EMAIL SIMULATION] " + event.email()
                        + " - " + event.bookingCode());
            }));
        }

        void awaitCompletion() {
            CompletableFuture.allOf(pending.toArray(CompletableFuture[]::new)).join();
        }

        boolean delivered(String bookingCode) {
            synchronized (delivered) {
                return delivered.contains(bookingCode);
            }
        }
    }

    static class AuditObserver implements BookingObserver {
        int received;

        public void update(BookingConfirmed event) {
            received++;
            System.out.println("[AUDIT SIMULATION] " + event.bookingCode());
        }
    }

    static void simulateTransaction(BookingSubject subject,
                                    BookingConfirmed event, boolean commit) {
        if (commit) {
            System.out.println("[TRANSACTION SIMULATION] COMMIT " + event.bookingCode());
            subject.notifyObservers(event);
        } else {
            System.out.println("[TRANSACTION SIMULATION] ROLLBACK " + event.bookingCode());
        }
    }

    static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
    }

    public static void main(String[] args) {
        BookingSubject subject = new BookingSubject();
        EmailObserver email = new EmailObserver();
        AuditObserver audit = new AuditObserver();
        subject.subscribe(email);
        subject.subscribe(audit);

        simulateTransaction(subject, new BookingConfirmed("BK-001", "patient@example.com"), true);
        simulateTransaction(subject, new BookingConfirmed("BK-002", "patient@example.com"), false);
        email.awaitCompletion();
        check(email.delivered("BK-001"), "Committed event must reach email observer");
        check(!email.delivered("BK-002"), "Rolled back event must not reach observers");
        check(audit.received == 1, "Two observers must receive the same committed event");

        subject.unsubscribe(audit);
        simulateTransaction(subject, new BookingConfirmed("BK-003", "patient@example.com"), true);
        email.awaitCompletion();
        check(email.delivered("BK-003"), "Remaining observer must still receive events");
        check(audit.received == 1, "Unsubscribed observer must not receive new events");
        System.out.println("PASS: commit, rollback, multiple observers, unsubscribe.");
    }
}
