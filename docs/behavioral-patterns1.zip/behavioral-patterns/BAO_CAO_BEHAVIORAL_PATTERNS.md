# VẬN DỤNG NHÓM MẪU THIẾT KẾ HÀNH VI TRONG HỆ THỐNG ĐẶT LỊCH KHÁM BỆNH

## Tóm tắt

Trong hệ thống đặt lịch khám bệnh, việc lưu một lịch hẹn chỉ là một phần của quá trình xử lý. Hệ thống còn cần gửi email xác nhận, cung cấp danh sách bác sĩ và cập nhật các khung giờ khám khả dụng. Khi các trách nhiệm này được gộp vào cùng một khối xử lý, mã nguồn dễ phụ thuộc chặt chẽ vào dịch vụ SMTP, Redis và các thành phần hạ tầng khác. Hệ quả là một thay đổi nhỏ về cách gửi thông báo hoặc cách lưu cache có thể ảnh hưởng trực tiếp đến nghiệp vụ đặt lịch.

Báo cáo phân tích hai mẫu thuộc nhóm Behavioral Patterns đang hiện diện trong dự án: **Observer** trong cơ chế phát sự kiện thông báo email và **Strategy** trong việc thay thế cách xử lý cache. Với mỗi mẫu, báo cáo trình bày bài toán, cơ sở lý thuyết, ánh xạ vai trò vào các lớp thực tế, mã nguồn, luồng hoạt động, kết quả minh họa và giới hạn của giải pháp. Các demo Java độc lập được bổ sung để có thể trình diễn cơ chế của mẫu mà không cần khởi động MySQL, Redis, RabbitMQ hoặc SMTP.

## Mục lục

1. Bối cảnh và phạm vi nghiên cứu
2. Cơ sở lý thuyết về Behavioral Patterns
3. Observer Pattern trong thông báo email
4. Strategy Pattern trong xử lý cache
5. So sánh và đánh giá hai mẫu
6. Kịch bản trình diễn và kiểm chứng
7. Kết luận
8. Tài liệu đối chiếu và phụ lục mã nguồn

## 1. Bối cảnh và phạm vi nghiên cứu

### 1.1. Bối cảnh ứng dụng

Dự án DatLichKhamBenh phục vụ ba nhóm người dùng: bệnh nhân, bác sĩ và quản trị viên. Bệnh nhân có thể tra cứu bác sĩ, xem ca khám, đặt lịch và hủy lịch. Bác sĩ quản lý ca làm việc, xem các cuộc hẹn và cập nhật trạng thái khám. Quản trị viên quản lý dữ liệu và phê duyệt bác sĩ. Backend sử dụng Spring Boot, dữ liệu nghiệp vụ được lưu trong MySQL; Redis hỗ trợ cache; RabbitMQ hỗ trợ chuyển giao tác vụ gửi email.

Luồng nghiệp vụ đặt lịch cần bảo đảm một khung giờ không bị nhiều bệnh nhân chiếm đồng thời. Trong code hiện có, `BookingServiceImpl.createBooking(...)` sử dụng transaction và gọi repository khóa bản ghi lịch làm việc. Sau khi kiểm tra điều kiện hợp lệ, service lưu `Appointment`, đánh dấu `Schedule` không còn khả dụng, xóa cache slot và yêu cầu gửi email xác nhận. Observer được phân tích ở bước thông báo; mẫu này không thay thế cơ chế khóa tranh chấp hoặc transaction.

### 1.2. Mục tiêu

Mục tiêu thứ nhất là giải thích cách tách phản ứng gửi email khỏi quá trình xử lý đặt lịch. Mục tiêu thứ hai là giải thích cách các service sử dụng hành vi cache thông qua một hợp đồng chung. Báo cáo không chỉ nêu tên các mẫu mà chỉ ra lời gọi cụ thể, trách nhiệm của từng lớp và điều kiện để giải pháp hoạt động.

### 1.3. Phạm vi và phương pháp

Nội dung được xây dựng bằng cách đọc mã nguồn tại `backend/src/main/java/com/datlichkhambenh/backend`, cấu hình trong `application.yml`, cùng mô tả kiến trúc và schema của dự án. Mã nguồn backend là căn cứ xác định phần đã triển khai. Demo độc lập chỉ dùng để giải thích mẫu; không được xem là kiểm thử tích hợp Spring hoặc bằng chứng rằng email thực tế đã đến hộp thư người nhận.

Hai mẫu được chọn đều có cơ sở trong code. Tuy nhiên, Strategy ở đây là cách đọc cấu trúc thay thế hành vi cache qua interface: lớp Redis thật và lớp NoOp dùng khi test. Không khẳng định dự án đã có bộ chọn thuật toán động hoặc một hệ thống chiến lược tính giá khám.

## 2. Cơ sở lý thuyết về Behavioral Patterns

### 2.1. Khái niệm

Mẫu thiết kế là cách tổ chức các thành phần phần mềm để giải quyết một dạng vấn đề thường gặp trong một bối cảnh nhất định. Behavioral Patterns tập trung vào sự phối hợp giữa các đối tượng: ai yêu cầu xử lý, ai thực hiện, dữ liệu được chuyển như thế nào và trách nhiệm được phân chia ở đâu. Trong báo cáo này, điểm quan tâm là quan hệ giữa các thành phần khi một sự kiện xảy ra và khả năng thay thế một hành vi mà vẫn giữ nguyên cách gọi của thành phần sử dụng.

Không thể kết luận một hệ thống sử dụng mẫu chỉ vì tồn tại interface, annotation hoặc một lớp có tên tương tự mẫu. Cần đối chiếu cấu trúc và ý nghĩa: Observer phải có bên phát và bên phản ứng với thông báo; Strategy phải có các hành vi thay thế tuân theo cùng một hợp đồng và một context sử dụng hợp đồng đó.

### 2.2. Nguyên tắc thiết kế liên quan

**Single Responsibility:** nghiệp vụ đặt lịch chịu trách nhiệm về tính hợp lệ của cuộc hẹn, publisher chịu trách nhiệm chuyển yêu cầu thông báo, consumer chịu trách nhiệm dựng và gửi email. Tương tự, service tra cứu bác sĩ không cần tự triển khai JSON serialization và TTL của Redis.

**Dependency Inversion:** context phụ thuộc vào interface như `RedisCacheService`, thay vì trực tiếp tạo `StringRedisTemplate`. Sự phụ thuộc vào chi tiết hạ tầng được đặt tại implementation tương ứng.

**Open/Closed:** có thể bổ sung một listener hoặc một implementation cache mà giảm số điểm cần sửa trong nghiệp vụ. Nguyên tắc này không có nghĩa mọi mở rộng đều không cần thay đổi cấu hình; chẳng hạn thêm strategy mới vẫn cần quy tắc chọn bean rõ ràng.

### 2.3. Hai vấn đề được lựa chọn

| Vấn đề | Yêu cầu thay đổi | Mẫu phù hợp |
| --- | --- | --- |
| Đặt lịch phát sinh nhu cầu gửi thông báo | Bên đặt lịch không cần nắm cách gửi SMTP hoặc cách xử lý từng phản ứng | Observer |
| Cùng một thao tác cache có cách triển khai khác nhau giữa các môi trường | Service gọi cùng hợp đồng dù dùng Redis thật hay bỏ qua cache | Strategy |

## 3. Observer Pattern trong thông báo email

### 3.1. Bài toán trước khi áp dụng

Giả sử service đặt lịch gọi trực tiếp máy chủ SMTP trước khi trả kết quả cho bệnh nhân. Khi SMTP chậm, thời gian chờ của request tăng theo. Nếu lời gọi diễn ra trong transaction, transaction cũng có thể bị giữ lâu hơn chỉ vì một tác vụ thông báo. Ngoài ra, email có thể đã được gửi nhưng thao tác lưu dữ liệu sau đó thất bại, khiến bệnh nhân nhận xác nhận cho một cuộc hẹn chưa tồn tại hợp lệ.

Đoạn mã sau chỉ minh họa cách ghép trách nhiệm cần tránh, **không phải mã backend hiện tại**:

```java
// Giả mã: đặt lịch và SMTP bị ghép trực tiếp.
Appointment saved = appointmentRepository.save(appointment);
mailSender.send(buildConfirmation(saved));
return mapToDto(saved);
```

Có hai vấn đề độc lập cần giải quyết. Observer giúp tách bên phát thông báo khỏi bên phản ứng. Cơ chế xử lý sau commit và bất đồng bộ giúp ràng buộc thời điểm thực hiện, đồng thời đưa công việc gửi mail ra khỏi đường chờ SMTP của request. Bản thân Observer không mặc định làm một lời gọi trở thành bất đồng bộ.

### 3.2. Cấu trúc mẫu

Ở dạng tổng quát, Subject quản lý hoặc sử dụng một cơ chế đăng ký observer. Khi xuất hiện thay đổi có ý nghĩa, subject phát thông báo. Observer nhận thông báo qua hợp đồng thống nhất và tự thực hiện trách nhiệm riêng. Cùng một sự kiện có thể được nhiều observer xử lý mà bên phát không cần gọi trực tiếp từng lớp cụ thể.

Trong Spring, container và cơ chế application event đảm nhiệm việc tìm các listener tương ứng. Do đó, dự án không cần tự viết một danh sách observer trong service đặt lịch. `AsyncEmailNotificationServiceImpl` khởi phát thông báo qua `ApplicationEventPublisher`, còn `EmailQueuePublisher` đăng ký xử lý bằng annotation.

| Thành phần mẫu | Ánh xạ trong dự án | Ý nghĩa |
| --- | --- | --- |
| Client nghiệp vụ | `BookingServiceImpl` | Yêu cầu gửi xác nhận sau khi xử lý dữ liệu lịch hẹn |
| Bên khởi phát / vai trò Subject ở mức ứng dụng | `AsyncEmailNotificationServiceImpl` | Chuẩn bị dữ liệu và phát sự kiện |
| Cơ chế phân phối | Spring `ApplicationEventPublisher` | Chuyển sự kiện tới listener phù hợp |
| Event | `EmailNotificationRequestedEvent` | Đóng gói thông tin yêu cầu thông báo |
| Observer | `EmailQueuePublisher` | Phản ứng sau commit, đẩy message vào broker |
| Thành phần xử lý tiếp theo | `EmailQueueConsumer` | Nhận message RabbitMQ và thực hiện gửi SMTP |

Không nên gọi consumer là listener trực tiếp của Spring event: consumer đăng ký với queue RabbitMQ, còn `EmailQueuePublisher` mới là observer của application event. Đây là hai chặng kết nối có ranh giới khác nhau.

### 3.3. Thiết kế dữ liệu sự kiện

`EmailNotificationMessage` chứa loại thông báo, email người nhận, tên bệnh nhân, mã đặt lịch, tên bác sĩ, ngày giờ khám và giá khám. `EmailNotificationRequestedEvent` bao bên ngoài message đó. Cách tổ chức này chuyển dữ liệu cần cho việc gửi mail thay vì chuyển nguyên đối tượng JPA sang consumer.

```java
public record EmailNotificationRequestedEvent(EmailNotificationMessage message) {
}
```

Việc chụp các giá trị cần thiết trước khi chuyển sang xử lý nền làm giảm nhu cầu truy cập lại quan hệ entity ngoài transaction. Khi consumer hoạt động, nó đọc dữ liệu message thay vì dựa vào một Hibernate session còn mở. Tuy nhiên, thiết kế hiện tại chưa có mã định danh sự kiện riêng để chống gửi trùng; `bookingCode` là thông tin nghiệp vụ, không tự động tạo ra cơ chế idempotency.

### 3.4. Phát sự kiện từ dịch vụ thông báo

`AsyncEmailNotificationService` cung cấp ba phương thức: gửi xác nhận, nhắc lịch và thông báo hủy. Implementation quy về một hàm `publish(...)`, chọn loại thông báo tương ứng rồi gọi:

```java
eventPublisher.publishEvent(new EmailNotificationRequestedEvent(message));
```

Lời gọi này thể hiện điểm tách trách nhiệm. Dịch vụ không tạo `EmailQueuePublisher`, không gọi SMTP và không cần biết tên queue cụ thể. Chi tiết broker nằm ở publisher và cấu hình messaging. Việc dựng message vẫn diễn ra trong lời gọi hiện tại; tên lớp có chữ Async không có nghĩa mọi câu lệnh của lớp đều tự chạy trên thread khác.

### 3.5. Lắng nghe sau khi database commit

Đoạn mã trọng tâm của `EmailQueuePublisher` là:

```java
@Async
@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
public void publishAfterCommit(EmailNotificationRequestedEvent event) {
    try {
        rabbitTemplate.convertAndSend(exchange, routingKey, event.message());
        log.info("Queued email notification for booking {}", event.message().bookingCode());
    } catch (Exception ex) {
        log.error("Cannot queue email notification for booking {}: {}",
                event.message().bookingCode(), ex.getMessage());
    }
}
```

`AFTER_COMMIT` ràng buộc xử lý vào kết quả giao dịch: nếu transaction rollback, listener ở phase này không thực hiện publish. `@Async` cho phép phần thân listener chạy qua executor khi cơ chế async đã được bật. Hai annotation giải quyết hai yêu cầu khác nhau: đúng thời điểm và tách công việc khỏi thread gọi.

Nếu sự kiện được phát ngoài transaction, cấu hình hiện tại không bật `fallbackExecution`, do đó không thể kỳ vọng listener vẫn xử lý. Khi mở rộng hệ thống để phát sự kiện từ tác vụ nhắc lịch, cần kiểm tra ranh giới transaction của điểm gọi mới thay vì chỉ gọi lại hàm và mặc định mail sẽ được xếp hàng.

### 3.6. Chuyển giao qua RabbitMQ và gửi SMTP

`RabbitMqConfig` khai báo direct exchange, queue và binding theo routing key. Với cấu hình mặc định trong dự án, exchange là `clinic.email.exchange`, queue là `clinic.email.queue`, routing key là `clinic.email.send`. `RabbitTemplate` chuyển message bằng JSON converter. Publisher chỉ chuyển yêu cầu; consumer độc lập nhận message bằng `@RabbitListener`.

Trong `EmailQueueConsumer`, loại `BOOKING_CANCELLED` chọn tiêu đề hủy lịch, `APPOINTMENT_REMINDER` chọn tiêu đề nhắc lịch, còn mặc định là xác nhận đặt lịch. Consumer dựng `SimpleMailMessage` rồi gọi `JavaMailSender.send(...)`. Nếu SMTP bị chậm, tác động trực tiếp nằm ở quá trình xử lý consumer, không buộc request đặt lịch chờ SMTP kết thúc.

### 3.7. Diễn giải một tình huống cụ thể

Giả sử bệnh nhân đặt một slot còn trống và nhận mã `BK-001`. Service khóa và kiểm tra slot, lưu lịch hẹn, đổi trạng thái slot, xóa cache rồi phát yêu cầu thông báo. Transaction commit thành công; listener được kích hoạt để chuyển message sang RabbitMQ. Consumer nhận message chứa `BK-001`, dựng nội dung xác nhận và gửi mail.

Nếu transaction bị rollback trước khi hoàn tất, sự kiện đã được phát trong transaction không làm listener `AFTER_COMMIT` xếp mail. Nếu database đã commit nhưng RabbitMQ không truy cập được, lịch hẹn vẫn đã được ghi nhận; publisher hiện ghi lỗi và không có cơ chế outbox để tự khôi phục tác vụ bị mất. Vì vậy, cần phân biệt “đặt lịch thành công” với “email đã được gửi thành công”.

### 3.8. Đánh giá hiệu năng

Gọi thời gian xử lý nghiệp vụ là `T_nghiep_vu`, thời gian dựng message/phát event là `T_event`, thời gian gửi SMTP là `T_smtp`. Trong mô hình gọi SMTP đồng bộ, đường chờ có thể xấp xỉ `T_nghiep_vu + T_smtp`. Trong thiết kế hiện tại, phần SMTP nằm ở consumer; đường chờ request chủ yếu gồm nghiệp vụ, tạo event và chi phí điều phối sau commit. Đây là mô hình phân tích, chưa phải số liệu benchmark.

Không thể khẳng định hệ thống nhanh hơn một tỷ lệ cụ thể khi chưa đo. Khi đánh giá thực nghiệm, cần ghi riêng thời gian phản hồi API, độ trễ từ commit đến lúc consumer nhận message, thời gian SMTP và số message tồn đọng. Những đại lượng này phản ánh trải nghiệm người dùng và khả năng xử lý nền ở hai khía cạnh khác nhau.

### 3.9. Ưu điểm, hạn chế và hướng phát triển

Ưu điểm chính là giảm phụ thuộc giữa nghiệp vụ đặt lịch và cơ chế gửi mail. Việc chuyển nội dung mail, đổi nhà cung cấp SMTP hoặc bổ sung một phản ứng khác có thể được đặt ở thành phần phù hợp. Việc thực hiện sau commit tránh một lớp sai lệch rõ ràng: thông báo xác nhận cho transaction bị rollback.

Đổi lại, hệ thống có thêm executor, broker và consumer cần theo dõi. Lỗi xử lý nền không thể được thể hiện đơn giản bằng kết quả trả về của request ban đầu. Nếu không có log liên kết theo mã lịch hẹn, việc truy tìm một email thất lạc trở nên khó khăn hơn so với một lời gọi đồng bộ duy nhất.

Queue durable không đủ để chứng minh bảo đảm gửi email đầu cuối. Code hiện tại chưa cung cấp transactional outbox, retry có giới hạn, DLQ hay cơ chế chống gửi trùng trong luồng này. `default-requeue-rejected: false` cũng không đồng nghĩa đã có một hàng đợi lỗi; cần cấu hình dead-letter tương ứng nếu muốn giữ lại message bị từ chối.

Hướng cải tiến là lưu outbox cùng transaction đặt lịch, có tiến trình chuyển sự kiện từ outbox sang broker, bổ sung publisher confirms và quan sát lỗi định tuyến. Phía consumer cần retry có giới hạn, nơi lưu message lỗi và khóa nhận diện thông báo đã xử lý. Các giải pháp đó giúp thu hẹp khoảng trống chuyển giao, nhưng vẫn phải thiết kế cẩn thận vì gửi SMTP và cập nhật trạng thái xử lý không phải một transaction nguyên tử chung.

### 3.10. Sơ đồ và mã nguồn đi kèm

- [Observer.drawio](01-observer/Observer.drawio): cấu trúc thành phần và luồng xử lý.
- [ObserverDemo.java](01-observer/code-demo/ObserverDemo.java): ví dụ Subject/Observer độc lập, có nhiều observer và thao tác hủy đăng ký.
- [Phụ lục code Observer](01-observer/MA_NGUON_VA_PHAN_TICH.md): bản đầy đủ các lớp email và cấu hình liên quan, cùng đoạn tích hợp nghiệp vụ.

## 4. Strategy Pattern trong xử lý cache

### 4.1. Bài toán thực tế

Danh sách bác sĩ và slot rảnh là các dữ liệu được đọc nhiều lần. Redis giúp giảm truy vấn database khi dữ liệu cache còn hiệu lực. Tuy nhiên, các bài kiểm thử service không phải lúc nào cũng cần một Redis server thật. Nếu code nghiệp vụ vừa thực hiện tìm kiếm vừa tự kiểm tra profile và thao tác Redis, việc kiểm thử sẽ khó hơn và các nhánh xử lý hạ tầng dễ bị lặp lại.

Nhu cầu ở đây là giữ ổn định lời gọi từ nghiệp vụ, đồng thời thay đổi cách xử lý cache. Khi chạy bình thường, thao tác đọc/ghi/xóa thực hiện trên Redis. Khi dùng profile test, thao tác đọc trả cache miss, còn ghi/xóa không làm gì. Hai cách xử lý có cùng hợp đồng nhưng khác hành vi.

### 4.2. Cấu trúc mẫu và ánh xạ

Strategy đóng gói các hành vi có thể thay thế sau một interface. Context nhận một implementation thông qua cơ chế lựa chọn phù hợp và chỉ gọi các phương thức của interface. Trong dự án, interface có tên `RedisCacheService`; mặc dù tên gắn với Redis, nó đang được dùng như hợp đồng chung cho hai hành vi: cache bằng Redis và bỏ qua cache.

| Vai trò | Lớp hoặc cơ chế thực tế | Trách nhiệm |
| --- | --- | --- |
| Strategy | `RedisCacheService` | Quy định thao tác cache bác sĩ và slot |
| ConcreteStrategy thứ nhất | `RedisCacheServiceImpl` | Thao tác Redis, chuyển đổi JSON, áp dụng TTL |
| ConcreteStrategy thứ hai | `NoOpRedisCacheService` | Đọc trả `null`, ghi/xóa không thao tác |
| Context | `DoctorServiceImpl`, `DoctorScheduleServiceImpl`, `BookingServiceImpl` | Sử dụng hợp đồng cache trong nghiệp vụ |
| Cơ chế lựa chọn | Spring profile và dependency injection | Chọn implementation lúc khởi động |

### 4.3. Hợp đồng Strategy

```java
public interface RedisCacheService {
    List<DoctorDto> getCachedDoctors(Long specialtyId);
    void cacheDoctors(Long specialtyId, List<DoctorDto> doctors);
    void evictDoctorCache(Long specialtyId);
    List<ScheduleDto> getCachedAvailableSlots(Long doctorId, LocalDate date);
    void cacheAvailableSlots(Long doctorId, LocalDate date, List<ScheduleDto> slots);
    void evictSlotCache(Long doctorId, LocalDate date);
}
```

Interface mô tả thao tác theo dữ liệu nghiệp vụ thay vì bắt context làm việc với chuỗi JSON hoặc lệnh Redis. Quy ước quan trọng là `null` biểu thị không có dữ liệu cache. Một danh sách rỗng vẫn có thể là dữ liệu hợp lệ: chẳng hạn bác sĩ không còn slot rảnh. Nhầm lẫn hai giá trị này sẽ dẫn đến truy vấn database không cần thiết hoặc trả kết quả sai.

### 4.4. Strategy sử dụng Redis

`RedisCacheServiceImpl` nhận `StringRedisTemplate` và `ObjectMapper`. Khi đọc danh sách bác sĩ, implementation tạo key theo chuyên khoa, đọc chuỗi JSON rồi chuyển thành `List<DoctorDto>`. Nếu key không tồn tại hoặc đọc thất bại, phương thức trả `null`. Khi ghi, implementation serialize danh sách và đặt TTL; cấu hình mặc định là 300 giây cho danh sách bác sĩ và 60 giây cho slot rảnh.

Việc gom xử lý JSON, key và TTL vào một lớp làm context dễ đọc hơn. Tuy vậy, implementation cũng có đánh đổi: việc bắt lỗi Redis và trả cache miss giúp luồng nghiệp vụ tiếp tục truy vấn database, nhưng có thể làm tải database tăng mạnh khi cache gặp sự cố. Khả năng bỏ qua cache không đồng nghĩa toàn hệ thống giữ được hiệu năng như khi cache đang hoạt động.

### 4.5. Strategy NoOp

```java
@Service
@Profile("test")
public class NoOpRedisCacheService implements RedisCacheService {
    public List<DoctorDto> getCachedDoctors(Long specialtyId) { return null; }
    public void cacheDoctors(Long specialtyId, List<DoctorDto> doctors) { }
    public void evictDoctorCache(Long specialtyId) { }
    public List<ScheduleDto> getCachedAvailableSlots(Long doctorId, LocalDate date) { return null; }
    public void cacheAvailableSlots(Long doctorId, LocalDate date, List<ScheduleDto> slots) { }
    public void evictSlotCache(Long doctorId, LocalDate date) { }
}
```

NoOp không cần mô phỏng một Redis đầy đủ. Nó bảo đảm rằng các phương thức vẫn có thể được gọi trong cùng vị trí nhưng không thực hiện I/O cache. Context nhận `null`, chạy nhánh truy vấn repository và trả kết quả nghiệp vụ như bình thường. Đây cũng là đặc điểm của Null Object: cung cấp một đối tượng tuân thủ hợp đồng nhưng có hành vi rỗng phù hợp.

### 4.6. Context không biết implementation cụ thể

Trong `DoctorServiceImpl`, dependency được khai báo:

```java
private final RedisCacheService redisCacheService;
```

Context gọi `getCachedDoctors(specialtyId)`. Nếu kết quả là `null`, nó truy vấn repository theo chuyên khoa, chuyển entity sang DTO và gọi `cacheDoctors(...)`. Phần lọc từ khóa, mức phí, kinh nghiệm và sắp xếp vẫn thuộc nghiệp vụ của context. Việc đổi strategy không chuyển những quy tắc tìm kiếm đó sang implementation cache.

Tương tự, `DoctorScheduleServiceImpl.getAvailableSlots(...)` đọc cache slot trước khi truy vấn danh sách slot còn rảnh. `BookingServiceImpl` gọi `evictSlotCache(...)` khi lịch hẹn làm thay đổi trạng thái slot. Cả ba service đều dùng hợp đồng chung, không tự tạo implementation Redis trong từng phương thức.

### 4.7. Cơ chế lựa chọn theo profile

`RedisCacheServiceImpl` mang `@Profile("!test")`, trong khi `NoOpRedisCacheService` mang `@Profile("test")`. Khi profile test hoạt động, implementation Redis bị loại theo điều kiện profile và NoOp được sử dụng. Khi profile test không hoạt động, implementation Redis được chọn. Spring tiêm bean phù hợp khi khởi tạo context.

Đây là lựa chọn tại thời điểm khởi động. Code hiện tại không có `setStrategy(...)` để thay đổi theo request, cũng không tự chuyển sang NoOp khi Redis mất kết nối. Nếu Redis gặp lỗi đọc, chính implementation Redis bắt lỗi và trả miss; bean vẫn là `RedisCacheServiceImpl`.

### 4.8. Phân biệt Strategy với các kỹ thuật liên quan

**Dependency injection** là cách cung cấp dependency cho context. **Strategy** mô tả quan hệ giữa các hành vi thay thế và context sử dụng chúng. Trong trường hợp này, DI giúp lắp ghép strategy, nhưng hai khái niệm không đồng nhất.

**Cache-aside** mô tả cách đọc dữ liệu: thử cache, miss thì lấy database rồi điền lại cache. **Strategy** mô tả cách thay thế implementation cache. Một hệ thống có thể dùng cache-aside mà chỉ có một implementation; ngược lại có thể có nhiều cache strategy nhưng lựa chọn một cách phối hợp đọc/ghi khác.

**Null Object** mô tả hành vi rỗng an toàn của NoOp. Một lớp có thể tham gia nhiều cách nhìn thiết kế nếu mỗi cách nhìn đều có căn cứ; không cần coi các tên mẫu là các nhãn loại trừ nhau.

### 4.9. Tình huống minh họa và đánh giá

Giả sử hai request liên tiếp tra cứu cùng một chuyên khoa, không có thay đổi dữ liệu ở giữa. Với cache hoạt động, request đầu miss và truy vấn repository, request sau có thể hit. Với NoOp, cả hai request đều miss và truy vấn repository. Dữ liệu nghiệp vụ mong đợi tương đương trong điều kiện dữ liệu nguồn không thay đổi, nhưng số lần truy vấn khác nhau.

Demo độc lập dùng cache bộ nhớ để kiểm chứng cấu trúc thay thế mà không cần Redis. Kết quả đếm một truy vấn cho hai lần đọc có cache, hai truy vấn khi dùng NoOp là kết quả trên repository giả lập. Không sử dụng số đếm này để suy ra throughput, độ trễ Redis hoặc hiệu năng production.

Ưu điểm của thiết kế là giảm điều kiện môi trường trong service và hỗ trợ kiểm thử đơn giản hơn. Hạn chế là hợp đồng đang dùng `null` thay cho một kiểu kết quả biểu đạt cache hit/miss rõ ràng, tên interface còn gắn với công nghệ và profile chưa cho phép lựa chọn linh hoạt nhiều loại cache. Nếu mở rộng thêm implementation, phải bảo đảm quy tắc chọn bean không gây mơ hồ.

Việc xóa cache trước commit trong luồng đặt lịch còn có thể phát sinh cạnh tranh: một request khác nạp lại giá trị cũ trong lúc transaction chưa commit. Đây là vấn đề nhất quán của cơ chế vô hiệu hóa cache, không phải lỗi được Strategy tự giải quyết. Hướng cải tiến là xem xét xóa cache sau commit và thiết kế chính sách nhất quán phù hợp với mức tải thực tế.

### 4.10. Sơ đồ và mã nguồn đi kèm

- [Strategy.drawio](02-strategy/Strategy.drawio): cấu trúc interface, context và hai implementation.
- [StrategyDemo.java](02-strategy/code-demo/StrategyDemo.java): kiểm chứng thay thế hành vi, cache hit/miss và eviction.
- [Phụ lục code Strategy](02-strategy/MA_NGUON_VA_PHAN_TICH.md): interface, hai implementation và các điểm gọi trong nghiệp vụ.

## 5. So sánh và đánh giá hai mẫu

| Tiêu chí | Observer | Strategy |
| --- | --- | --- |
| Vấn đề chính | Phân phối thông báo và tách phản ứng | Thay thế cách thực hiện cùng hợp đồng |
| Quan hệ | Bên phát với một hoặc nhiều listener | Context với strategy được cung cấp |
| Dữ liệu trao đổi | Event chứa message email | Tham số và giá trị trả về của thao tác cache |
| Thời điểm lựa chọn trong dự án | Listener được Spring đăng ký; xử lý theo phase transaction | Bean được chọn theo profile lúc khởi động |
| Tác dụng thực tế | Tách SMTP khỏi đường chờ request; publish sau commit | Dùng Redis thật hoặc bỏ cache trong test qua cùng interface |
| Giới hạn | Không tự bảo đảm giao nhận thành công hoặc không trùng | Không tự bảo đảm nhất quán cache hoặc failover động |

Hai mẫu cùng giảm phụ thuộc nhưng tác động lên hai kiểu quan hệ khác nhau. Observer tách bên phát khỏi các phản ứng; Strategy tách nơi sử dụng khỏi cách thực hiện. Trong một luồng đặt lịch, hai mẫu có thể cùng xuất hiện: service gọi cache strategy để vô hiệu hóa slot rồi yêu cầu phát sự kiện thông báo. Việc cùng thuộc nhóm Behavioral không có nghĩa hai mẫu có thể thay thế trực tiếp cho nhau.

## 6. Kịch bản trình diễn và kiểm chứng

### 6.1. Demo Java độc lập

Yêu cầu: JDK 21 như cấu hình backend. Từ thư mục gốc repository, chạy:

```powershell
java docs/behavioral-patterns/01-observer/code-demo/ObserverDemo.java
java docs/behavioral-patterns/02-strategy/code-demo/StrategyDemo.java
```

Đây là chế độ chạy trực tiếp file Java; không cần sao chép demo vào `backend/src/main/java`. Observer demo mô phỏng quyết định commit/rollback bằng tham số, không tạo transaction thật. Strategy demo dùng `HashMap` và repository giả lập, không kiểm tra Redis thật. Thứ tự xuất hiện log email nền có thể khác nhau; các điều kiện kiểm chứng dựa trên trạng thái sau khi đã chờ hoàn tất.

| Mã | Tình huống | Điều kiện kiểm chứng trong demo |
| --- | --- | --- |
| O1 | Commit sự kiện `BK-001` | Email observer và audit observer cùng nhận thông báo |
| O2 | Rollback sự kiện `BK-002` | Không observer nào xử lý sự kiện đó |
| O3 | Hủy đăng ký audit rồi commit `BK-003` | Email tiếp tục nhận, audit không nhận thêm |
| S1 | Đọc hai lần với cache bộ nhớ | Kết quả tương đương; repository được gọi một lần |
| S2 | Xóa key rồi đọc lại | Repository được gọi lại để nạp dữ liệu |
| S3 | Đổi sang context dùng NoOp | Giữ kết quả nghiệp vụ; hai lần đọc gọi repository hai lần |

Demo sử dụng các điều kiện kiểm tra ném `AssertionError` nếu kết quả không đúng. Những điều kiện này kiểm tra hành vi có thể quan sát được của mẫu: phản ứng với sự kiện, hủy đăng ký và số lần truy vấn khi đổi strategy.

### 6.2. Kế hoạch kiểm chứng tích hợp backend

Các trường hợp sau là **kế hoạch kiểm thử**, không phải kết quả chạy tích hợp được báo cáo ở đây.

| Tình huống | Cách quan sát | Kết quả mong đợi / giới hạn hiện tại |
| --- | --- | --- |
| Đặt lịch hợp lệ với hạ tầng đầy đủ | Đối chiếu DB, log mã lịch, queue và hộp thư thử nghiệm | Lịch được lưu, slot hết khả dụng, mail chứa đúng mã |
| Gây rollback sau khi phát event trong transaction thử nghiệm | Quan sát listener và queue | Không publish từ listener AFTER_COMMIT |
| RabbitMQ không truy cập được | Đối chiếu lịch trong DB và log publisher | Lịch có thể đã commit; lỗi queue được log, chưa có outbox tự phục hồi |
| SMTP lỗi khi consumer xử lý | Quan sát lỗi consumer và cấu hình reject | Không giả định tự retry hoặc giữ message nếu chưa cấu hình |
| Chạy profile test | Kiểm tra kiểu bean cache được tiêm | `NoOpRedisCacheService` được chọn |
| Redis gặp lỗi đọc ngoài profile test | Quan sát log và repository | Implementation Redis trả miss; không đổi bean sang NoOp |

### 6.3. Gợi ý trình bày khi bảo vệ

Đầu tiên, mở sơ đồ Observer để giải thích ranh giới transaction và vị trí bất đồng bộ. Sau đó chỉ ra ba đoạn code: `publishEvent`, `@TransactionalEventListener` và `@RabbitListener`. Chạy demo để minh họa thêm một observer mà không sửa subject và hủy đăng ký observer. Nêu rõ phần audit là ví dụ trong demo, chưa phải listener đã thêm vào backend.

Tiếp theo, mở sơ đồ Strategy và chỉ ra interface cùng hai implementation. Chạy demo để so sánh số lần truy vấn khi thay cách cache. Cuối cùng giải thích vì sao `@Profile` là lựa chọn lúc khởi động, và vì sao cache-aside, DI, Null Object là các khía cạnh liên quan nhưng không đồng nhất với Strategy.

## 7. Kết luận

Observer trong dự án được thể hiện qua application event và transactional listener: nghiệp vụ yêu cầu thông báo, còn listener sau commit chịu trách nhiệm chuyển yêu cầu sang RabbitMQ. Consumer thực hiện SMTP ở chặng xử lý riêng. Thiết kế giảm thời gian chờ SMTP của request và tránh xếp mail từ transaction bị rollback, nhưng vẫn cần cơ chế bổ sung nếu yêu cầu bảo đảm chuyển giao và phục hồi lỗi cao hơn.

Strategy được thể hiện qua `RedisCacheService` và hai cách triển khai Redis/NoOp. Các context giữ cùng cách gọi, còn hành vi cache được thay thế bằng cấu hình profile. Thiết kế hỗ trợ tách hạ tầng khỏi nghiệp vụ và kiểm thử, đồng thời vẫn để lại các vấn đề cần quản lý riêng như nhất quán cache, tải database khi cache lỗi và cách chọn implementation khi mở rộng.

Giá trị của việc vận dụng mẫu không chỉ nằm ở sơ đồ lớp mà ở việc xác định rõ trách nhiệm và giới hạn. Khi phân tích đúng ranh giới, có thể mở rộng hệ thống mà tránh quy cho mẫu những bảo đảm mà code thực tế chưa cung cấp.

## 8. Tài liệu đối chiếu và phụ lục mã nguồn

1. [Kiến trúc hệ thống](../../architecture.md): phân tầng, nghiệp vụ đặt lịch và yêu cầu gửi mail qua queue.
2. [Schema dữ liệu](../../schema.md): các bảng và quan hệ phục vụ đặt lịch.
3. [Phụ lục mã nguồn Observer](01-observer/MA_NGUON_VA_PHAN_TICH.md): code nguyên văn các thành phần thông báo.
4. [Phụ lục mã nguồn Strategy](02-strategy/MA_NGUON_VA_PHAN_TICH.md): code cache và trích đoạn context.
5. [Hướng dẫn demo và kết quả chạy](HUONG_DAN_CHAY_DEMO.md).

Phụ lục mã nguồn là bản chụp phục vụ báo cáo tại thời điểm tạo tài liệu. Khi chỉnh sửa backend về sau, cần cập nhật phụ lục; mã backend vẫn là nguồn triển khai chính.
