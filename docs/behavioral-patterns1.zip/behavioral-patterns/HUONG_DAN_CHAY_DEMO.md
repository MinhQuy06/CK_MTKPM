# Hướng dẫn chạy và kết quả demo

## 1. Điều kiện

Cài JDK 21 và chạy tại thư mục gốc repository. Hai demo không cần Maven, MySQL, Redis, RabbitMQ hoặc tài khoản email. Mỗi file tự chứa các thành phần cần thiết; không sao chép vào backend vì đây là ví dụ giảng giải độc lập.

## 2. Observer

```powershell
java docs/behavioral-patterns/01-observer/code-demo/ObserverDemo.java
```

`BookingSubject` cung cấp subscribe, unsubscribe và notify. `EmailObserver` mô phỏng xử lý nền bằng CompletableFuture; `AuditObserver` minh họa một phản ứng thứ hai. Hàm simulateTransaction chỉ mô phỏng quyết định commit/rollback, không kết nối database và không thay thế transaction Spring.

Kết quả đã chạy:

```text
[TRANSACTION SIMULATION] COMMIT BK-001
[AUDIT SIMULATION] BK-001
[TRANSACTION SIMULATION] ROLLBACK BK-002
[EMAIL SIMULATION] patient@example.com - BK-001
[TRANSACTION SIMULATION] COMMIT BK-003
[EMAIL SIMULATION] patient@example.com - BK-003
PASS: commit, rollback, multiple observers, unsubscribe.
```

Thứ tự log của email có thể thay đổi do chạy nền. Các kiểm chứng được thực hiện sau khi chờ tác vụ hoàn tất: BK-001 được nhận, BK-002 không được nhận và audit không nhận BK-003 sau khi unsubscribe. Email dùng địa chỉ ví dụ và chỉ ghi log, không gửi ra ngoài.

## 3. Strategy

```powershell
java docs/behavioral-patterns/02-strategy/code-demo/StrategyDemo.java
```

`DoctorSearchContext` sử dụng `DoctorCacheStrategy`. `InMemoryCacheStrategy` giữ dữ liệu trong HashMap; `NoOpCacheStrategy` luôn miss. Hai context nhận strategy qua constructor, tương ứng với ý tưởng cung cấp implementation cho context. Demo không dùng annotation profile của Spring.

Kết quả đã chạy:

```text
PASS: cache miss, cache hit, eviction, interchangeable strategy.
Two reads: memory = 1 repository query; NoOp = 2 repository queries.
```

Demo xác minh kết quả nghiệp vụ tương đương khi đổi strategy và số lần gọi repository giả lập khác nhau. Kết quả không phải phép đo tốc độ Redis hoặc benchmark backend.

## 4. Sơ đồ dạng ảnh

Ảnh được xuất trực tiếp từ file Draw.io ở tỷ lệ 2x, có thể chèn vào Word hoặc slide:

- [Observer — thành phần](01-observer/Observer-thanh-phan.png).
- [Observer — luồng xử lý](01-observer/Observer-luong-xu-ly.png).
- [Strategy — cấu trúc](02-strategy/Strategy-cau-truc.png).

Giữ các file `.drawio` để chỉnh sửa và xuất lại ảnh khi thay đổi sơ đồ.
