# NHÓM BEHAVIORAL PATTERNS — MẪU HÀNH VI

Folder bài tiểu luận về **2 mẫu đã có trong code** của hệ thống đặt lịch khám bệnh, gồm báo cáo phân tích, phụ lục mã nguồn backend, demo Java độc lập và sơ đồ Draw.io kèm ảnh PNG.

## Bắt đầu đọc

- [Báo cáo tiểu luận đầy đủ](BAO_CAO_BEHAVIORAL_PATTERNS.md): lý thuyết, bài toán, thiết kế, phân tích code, đánh giá và kịch bản kiểm chứng.
- [Hướng dẫn và kết quả chạy demo](HUONG_DAN_CHAY_DEMO.md): hai demo đã chạy bằng JDK 21.
- [Mã nguồn Observer và phân tích](01-observer/MA_NGUON_VA_PHAN_TICH.md).
- [Mã nguồn Strategy và phân tích](02-strategy/MA_NGUON_VA_PHAN_TICH.md).

## Code demo chạy độc lập

```powershell
java docs/behavioral-patterns/01-observer/code-demo/ObserverDemo.java
java docs/behavioral-patterns/02-strategy/code-demo/StrategyDemo.java
```

Demo không cần hạ tầng ngoài; phần transaction, email và repository trong demo là mô phỏng. Code backend nguyên bản nằm trong phụ lục và các liên kết đối chiếu.

## Tài liệu và sơ đồ

| Mẫu | Vị trí áp dụng | Tài liệu | Sơ đồ Draw.io |
| --- | --- | --- | --- |
| Observer | Phát sự kiện yêu cầu gửi email sau giao dịch đặt lịch | [Observer](01-observer/README.md) | [Observer.drawio](01-observer/Observer.drawio) |
| Strategy | Thay thế cách xử lý cache thông qua `RedisCacheService` | [Strategy](02-strategy/README.md) | [Strategy.drawio](02-strategy/Strategy.drawio) |

Mở các tệp `.drawio` bằng ứng dụng Draw.io/diagrams.net qua **File → Open From → Device**. Mỗi tệp chứa các trang sơ đồ có thể chỉnh sửa trực tiếp.

### Ảnh Observer — thành phần

![Observer — thành phần](01-observer/Observer-thanh-phan.png)

### Ảnh Observer — luồng xử lý

![Observer — luồng xử lý](01-observer/Observer-luong-xu-ly.png)

### Ảnh Strategy — cấu trúc

![Strategy — cấu trúc](02-strategy/Strategy-cau-truc.png)

## Phân biệt hai mẫu

- **Observer:** một thành phần phát sự kiện; thành phần lắng nghe phản ứng mà bên phát không cần biết chi tiết xử lý.
- **Strategy:** các cách xử lý cùng một hợp đồng được đóng gói trong các lớp khác nhau; thành phần sử dụng chỉ phụ thuộc interface.

Các liên kết mã nguồn trong hai tài liệu trỏ về code hiện có trong repository. Các đề xuất cải tiến được ghi riêng, không phải tính năng đã triển khai.
