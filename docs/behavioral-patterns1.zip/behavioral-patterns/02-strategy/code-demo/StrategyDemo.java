import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Vi du Java doc lap: thay hanh vi cache, khong can Redis hay database that. */
public class StrategyDemo {
    interface DoctorCacheStrategy {
        List<String> get(Long specialtyId);
        void put(Long specialtyId, List<String> doctors);
        void evict(Long specialtyId);
    }

    static class InMemoryCacheStrategy implements DoctorCacheStrategy {
        private final Map<Long, List<String>> cache = new HashMap<>();

        public List<String> get(Long specialtyId) {
            return cache.get(specialtyId);
        }

        public void put(Long specialtyId, List<String> doctors) {
            cache.put(specialtyId, List.copyOf(doctors));
        }

        public void evict(Long specialtyId) {
            cache.remove(specialtyId);
        }
    }

    static class NoOpCacheStrategy implements DoctorCacheStrategy {
        public List<String> get(Long specialtyId) { return null; }
        public void put(Long specialtyId, List<String> doctors) { }
        public void evict(Long specialtyId) { }
    }

    static class DoctorRepositorySimulation {
        int queries;

        List<String> findApprovedDoctors(Long specialtyId) {
            queries++;
            return List.of("BS Nguyen An - specialty " + specialtyId);
        }
    }

    static class DoctorSearchContext {
        private final DoctorCacheStrategy cache;
        private final DoctorRepositorySimulation repository;

        DoctorSearchContext(DoctorCacheStrategy cache, DoctorRepositorySimulation repository) {
            this.cache = cache;
            this.repository = repository;
        }

        List<String> search(Long specialtyId) {
            List<String> result = cache.get(specialtyId);
            if (result == null) {
                result = repository.findApprovedDoctors(specialtyId);
                cache.put(specialtyId, result);
            }
            return result;
        }
    }

    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        DoctorRepositorySimulation repository = new DoctorRepositorySimulation();
        DoctorCacheStrategy memory = new InMemoryCacheStrategy();
        DoctorSearchContext cachedContext = new DoctorSearchContext(memory, repository);
        List<String> first = cachedContext.search(1L);
        check(first.equals(cachedContext.search(1L)), "Cache hit must preserve returned data");
        check(repository.queries == 1, "Two reads should require only one repository query");
        memory.evict(1L);
        cachedContext.search(1L);
        check(repository.queries == 2, "Read after eviction must reload data");

        DoctorRepositorySimulation uncachedRepository = new DoctorRepositorySimulation();
        DoctorSearchContext noOpContext = new DoctorSearchContext(new NoOpCacheStrategy(), uncachedRepository);
        check(first.equals(noOpContext.search(1L)), "Changing strategy must preserve business result");
        noOpContext.search(1L);
        check(uncachedRepository.queries == 2, "NoOp must query repository on every read");
        System.out.println("PASS: cache miss, cache hit, eviction, interchangeable strategy.");
        System.out.println("Two reads: memory = 1 repository query; NoOp = 2 repository queries.");
    }
}
