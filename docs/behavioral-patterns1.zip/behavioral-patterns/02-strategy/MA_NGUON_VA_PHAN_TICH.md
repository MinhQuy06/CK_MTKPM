# PHỤ LỤC MÃ NGUỒN VÀ PHÂN TÍCH — STRATEGY

Code dưới đây phản ánh implementation cache hiện có. Demo [StrategyDemo.java](code-demo/StrategyDemo.java) dùng bộ nhớ để minh họa thay thế hành vi, không giả lập đầy đủ Redis.

## 1. Strategy interface

Hợp đồng gồm đọc, ghi và xóa cho hai nhóm dữ liệu. null là cache miss; danh sách rỗng có thể là cache hit hợp lệ.

Nguồn: [RedisCacheService.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/RedisCacheService.java).

```java
package com.datlichkhambenh.backend.service;

import com.datlichkhambenh.backend.dto.response.DoctorDto;
import com.datlichkhambenh.backend.dto.response.ScheduleDto;

import java.time.LocalDate;
import java.util.List;

public interface RedisCacheService {
    List<DoctorDto> getCachedDoctors(Long specialtyId);
    void cacheDoctors(Long specialtyId, List<DoctorDto> doctors);
    void evictDoctorCache(Long specialtyId);

    List<ScheduleDto> getCachedAvailableSlots(Long doctorId, LocalDate date);
    void cacheAvailableSlots(Long doctorId, LocalDate date, List<ScheduleDto> slots);
    void evictSlotCache(Long doctorId, LocalDate date);
}
```

## 2. Concrete strategy: Redis

Implementation có @Profile("!test"). Chú ý cách tạo key, serialization, TTL và bắt lỗi. Khi đọc lỗi, lớp trả null; nó không thay đổi bean đang được tiêm.

Nguồn: [RedisCacheServiceImpl.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/RedisCacheServiceImpl.java).

```java
package com.datlichkhambenh.backend.service.impl;

import com.datlichkhambenh.backend.dto.response.DoctorDto;
import com.datlichkhambenh.backend.dto.response.ScheduleDto;
import com.datlichkhambenh.backend.service.RedisCacheService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.context.annotation.Profile;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@Profile("!test")
@RequiredArgsConstructor
public class RedisCacheServiceImpl implements RedisCacheService {

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    @Value("${app.cache.doctor-list-ttl:300}")
    private long doctorListTtl;

    @Value("${app.cache.available-slots-ttl:60}")
    private long availableSlotsTtl;

    @Override
    public List<DoctorDto> getCachedDoctors(Long specialtyId) {
        String key = "doctors:specialty:" + (specialtyId != null ? specialtyId : "all");
        try {
            String json = redisTemplate.opsForValue().get(key);
            if (json != null) {
                log.info("[Redis Cache] Hit for doctors list: {}", key);
                return objectMapper.readValue(json, new TypeReference<List<DoctorDto>>() {});
            }
        } catch (Exception e) {
            log.warn("[Redis Cache] Failed to read doctors cache: {}", e.getMessage());
        }
        return null;
    }

    @Override
    public void cacheDoctors(Long specialtyId, List<DoctorDto> doctors) {
        String key = "doctors:specialty:" + (specialtyId != null ? specialtyId : "all");
        try {
            String json = objectMapper.writeValueAsString(doctors);
            redisTemplate.opsForValue().set(key, json, doctorListTtl, TimeUnit.SECONDS);
            log.info("[Redis Cache] Cached doctors list under key: {}", key);
        } catch (Exception e) {
            log.warn("[Redis Cache] Failed to write doctors cache: {}", e.getMessage());
        }
    }

    @Override
    public void evictDoctorCache(Long specialtyId) {
        try {
            String key = "doctors:specialty:" + (specialtyId != null ? specialtyId : "all");
            redisTemplate.delete(key);
            redisTemplate.delete("doctors:specialty:all");
            log.info("[Redis Cache] Evicted doctors cache for key: {}", key);
        } catch (Exception e) {
            log.warn("[Redis Cache] Failed to evict doctors cache: {}", e.getMessage());
        }
    }

    @Override
    public List<ScheduleDto> getCachedAvailableSlots(Long doctorId, LocalDate date) {
        String key = String.format("slots:doctor:%d:date:%s", doctorId, date.toString());
        try {
            String json = redisTemplate.opsForValue().get(key);
            if (json != null) {
                log.info("[Redis Cache] Hit for available slots: {}", key);
                return objectMapper.readValue(json, new TypeReference<List<ScheduleDto>>() {});
            }
        } catch (Exception e) {
            log.warn("[Redis Cache] Failed to read slot cache: {}", e.getMessage());
        }
        return null;
    }

    @Override
    public void cacheAvailableSlots(Long doctorId, LocalDate date, List<ScheduleDto> slots) {
        String key = String.format("slots:doctor:%d:date:%s", doctorId, date.toString());
        try {
            String json = objectMapper.writeValueAsString(slots);
            redisTemplate.opsForValue().set(key, json, availableSlotsTtl, TimeUnit.SECONDS);
            log.info("[Redis Cache] Cached slots under key: {}", key);
        } catch (Exception e) {
            log.warn("[Redis Cache] Failed to write slot cache: {}", e.getMessage());
        }
    }

    @Override
    public void evictSlotCache(Long doctorId, LocalDate date) {
        String key = String.format("slots:doctor:%d:date:%s", doctorId, date.toString());
        try {
            redisTemplate.delete(key);
            log.info("[Redis Cache] Evicted slot cache for key: {}", key);
        } catch (Exception e) {
            log.warn("[Redis Cache] Failed to evict slot cache: {}", e.getMessage());
        }
    }
}
```

## 3. Concrete strategy: NoOp

@Profile("test") chọn hành vi bỏ qua cache. NoOp đồng thời mang đặc điểm Null Object; các context vẫn gọi cùng hợp đồng.

Nguồn: [NoOpRedisCacheService.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/NoOpRedisCacheService.java).

```java
package com.datlichkhambenh.backend.service.impl;

import com.datlichkhambenh.backend.dto.response.DoctorDto;
import com.datlichkhambenh.backend.dto.response.ScheduleDto;
import com.datlichkhambenh.backend.service.RedisCacheService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@Profile("test")
public class NoOpRedisCacheService implements RedisCacheService {
    public List<DoctorDto> getCachedDoctors(Long specialtyId) { return null; }
    public void cacheDoctors(Long specialtyId, List<DoctorDto> doctors) { }
    public void evictDoctorCache(Long specialtyId) { }
    public List<ScheduleDto> getCachedAvailableSlots(Long doctorId, LocalDate date) { return null; }
    public void cacheAvailableSlots(Long doctorId, LocalDate date, List<ScheduleDto> slots) { }
    public void evictSlotCache(Long doctorId, LocalDate date) { }
}
```

## 4. Context tìm kiếm bác sĩ

Đoạn này giữ nguyên dependency và phương thức searchApprovedDoctors. Nhánh null lấy database rồi điền cache; phần lọc/sắp xếp vẫn thuộc context.

Nguồn: [DoctorServiceImpl.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/DoctorServiceImpl.java). Trích đoạn, không phải lớp Java độc lập.

```java
    private final DoctorRepository doctorRepository;
    private final SpecialtyRepository specialtyRepository;
    private final RedisCacheService redisCacheService;

    @Override
    @Transactional(readOnly = true)
    public List<DoctorDto> searchApprovedDoctors(Long specialtyId, String keyword, BigDecimal minFee,
                                                  BigDecimal maxFee, Integer minExperience, String sort,
                                                  int page, int size) {
        List<DoctorDto> cached = redisCacheService.getCachedDoctors(specialtyId);
        if (cached == null) {
            List<Doctor> doctors = specialtyId == null
                    ? doctorRepository.findByIsApprovedTrueAndUserIsActiveTrue()
                    : doctorRepository.findBySpecialtyIdAndIsApprovedTrueAndUserIsActiveTrue(specialtyId);
            cached = doctors.stream().map(this::mapToDto).toList();
            redisCacheService.cacheDoctors(specialtyId, cached);
        }

        Stream<DoctorDto> stream = cached.stream();
        if (keyword != null && !keyword.isBlank()) {
            String normalized = keyword.trim().toLowerCase(Locale.ROOT);
            stream = stream.filter(d -> d.getFullName().toLowerCase(Locale.ROOT).contains(normalized));
        }
        if (minFee != null) stream = stream.filter(d -> d.getConsultationFee().compareTo(minFee) >= 0);
        if (maxFee != null) stream = stream.filter(d -> d.getConsultationFee().compareTo(maxFee) <= 0);
        if (minExperience != null) stream = stream.filter(d -> d.getExperienceYears() >= minExperience);

        Comparator<DoctorDto> comparator = switch (sort == null ? "name" : sort) {
            case "feeAsc" -> Comparator.comparing(DoctorDto::getConsultationFee);
            case "feeDesc" -> Comparator.comparing(DoctorDto::getConsultationFee).reversed();
            case "experience" -> Comparator.comparing(DoctorDto::getExperienceYears).reversed();
            default -> Comparator.comparing(DoctorDto::getFullName, String.CASE_INSENSITIVE_ORDER);
        };
        List<DoctorDto> filtered = stream.sorted(comparator).toList();
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), 100);
        int from = Math.min(safePage * safeSize, filtered.size());
        return filtered.subList(from, Math.min(from + safeSize, filtered.size()));
    }
```

## 5. Context tra cứu slot

Context kiểm tra ngày và bác sĩ, sau đó thực hiện cache-aside. Cùng một lời gọi hoạt động với Redis thật hoặc NoOp.

Nguồn: [DoctorScheduleServiceImpl.java](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/DoctorScheduleServiceImpl.java). Trích đoạn, không phải lớp Java độc lập.

```java
    @Override
    @Transactional(readOnly = true)
    public List<ScheduleDto> getAvailableSlots(Long doctorUserId, LocalDate date) {
        if (date.isBefore(LocalDate.now())) {
            return List.of();
        }
        Doctor doctor = doctorRepository.findById(doctorUserId)
                .filter(d -> Boolean.TRUE.equals(d.getIsApproved()) && Boolean.TRUE.equals(d.getUser().getIsActive()))
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy bác sĩ đang hoạt động"));
        // Pattern Cache-Aside: 1. Đọc từ Redis trước
        List<ScheduleDto> cached = redisCacheService.getCachedAvailableSlots(doctorUserId, date);
        if (cached != null) {
            return cached;
        }

        // 2. Cache miss -> query DB
        List<Schedule> slots = scheduleRepository.findByDoctorUserIdAndWorkDateAndIsAvailableTrue(doctorUserId, date);
        List<ScheduleDto> result = slots.stream().map(this::mapToDto).collect(Collectors.toList());

        // 3. Ghi lại vào Redis cache
        redisCacheService.cacheAvailableSlots(doctorUserId, date, result);

        return result;
    }
```

## 6. Điểm tích hợp vô hiệu hóa cache

Trong BookingServiceImpl, sau khi cập nhật slot, code gọi:

```java
redisCacheService.evictSlotCache(doctor.getUserId(), schedule.getWorkDate());
```

Context không cần biết lệnh Redis DELETE hoặc key cụ thể. Tuy nhiên, thời điểm xóa hiện nằm trước commit; Strategy không tự giải quyết các race condition về tính nhất quán cache.
