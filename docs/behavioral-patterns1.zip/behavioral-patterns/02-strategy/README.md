# Mẫu 2: Strategy Pattern — Lựa chọn cách xử lý cache

> Bản tiểu luận đầy đủ: [BAO_CAO_BEHAVIORAL_PATTERNS.md](../BAO_CAO_BEHAVIORAL_PATTERNS.md). Code backend đầy đủ và phân tích: [MA_NGUON_VA_PHAN_TICH.md](MA_NGUON_VA_PHAN_TICH.md). Demo chạy độc lập nằm trong thư mục `code-demo`.

**Trạng thái: đã có trong code**, với hai cách triển khai chung interface, được Spring chọn theo profile lúc khởi động. Không có cơ chế đổi strategy động trong từng request.

## Bài toán thực tế

Danh sách bác sĩ và slot rảnh cần cache để giảm truy vấn database. Khi kiểm thử, hệ thống cần chạy nghiệp vụ mà không phụ thuộc Redis. Nếu từng service tự kiểm tra môi trường và quyết định có gọi Redis hay không, logic hạ tầng sẽ lặp lại trong nghiệp vụ.

## Vị trí áp dụng và vai trò

| Vai trò Strategy | Thành phần thực tế | Trách nhiệm |
| --- | --- | --- |
| Strategy interface | [RedisCacheService](../../../backend/src/main/java/com/datlichkhambenh/backend/service/RedisCacheService.java) | Định nghĩa đọc, ghi và xóa cache bác sĩ/slot |
| Concrete strategy | [RedisCacheServiceImpl](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/RedisCacheServiceImpl.java) | Dùng Redis, chuyển đổi JSON và TTL; áp dụng `@Profile("!test")` |
| Concrete strategy không thao tác | [NoOpRedisCacheService](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/NoOpRedisCacheService.java) | Đọc trả `null`, ghi/xóa không thao tác; áp dụng `@Profile("test")` |
| Context | [DoctorServiceImpl](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/DoctorServiceImpl.java), [DoctorScheduleServiceImpl](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/DoctorScheduleServiceImpl.java), [BookingServiceImpl](../../../backend/src/main/java/com/datlichkhambenh/backend/service/impl/BookingServiceImpl.java) | Sử dụng `RedisCacheService` qua dependency injection |
| Cơ chế chọn | Spring profile và container | Chọn implementation phù hợp khi tạo bean |

`NoOpRedisCacheService` đồng thời mang đặc điểm **Null Object**. Góc nhìn Strategy ở đây là khả năng thay thế hành vi cache qua cùng một hợp đồng; bản thân dependency injection không tự động tạo thành Strategy nếu không có các hành vi thay thế.

## Giải pháp và luồng hoạt động

1. Service nghiệp vụ nhận `RedisCacheService` qua constructor do Lombok `@RequiredArgsConstructor` tạo.
2. Khi profile `test` hoạt động, Spring chọn `NoOpRedisCacheService`; khi profile `test` không hoạt động, Spring chọn `RedisCacheServiceImpl`.
3. Với danh sách bác sĩ, context gọi `getCachedDoctors(specialtyId)`. Nếu có dữ liệu thì trả cache; nếu trả `null` thì truy vấn repository, dựng DTO rồi gọi `cacheDoctors(...)`.
4. Với strategy NoOp, đọc luôn là cache miss; context tiếp tục truy vấn database và thao tác ghi cache kết thúc ngay.
5. Khi đặt lịch, `BookingServiceImpl` gọi `evictSlotCache(...)` qua cùng interface mà không cần biết strategy cụ thể.

```java
// Hợp đồng chung (trích)
public interface RedisCacheService {
    List<DoctorDto> getCachedDoctors(Long specialtyId);
    void cacheDoctors(Long specialtyId, List<DoctorDto> doctors);
    void evictSlotCache(Long doctorId, LocalDate date);
}

// Các implementation hiện có
@Service
@Profile("!test")
public class RedisCacheServiceImpl implements RedisCacheService { /* ... */ }

@Service
@Profile("test")
public class NoOpRedisCacheService implements RedisCacheService { /* ... */ }
```

Đây là đoạn trích minh họa, đã lược bỏ các phương thức khác và dependency.

## Lợi ích

- Context dùng một interface, không chứa nhánh điều kiện theo profile cho từng thao tác cache.
- Có thể kiểm thử các service sử dụng cache bằng strategy NoOp mà không cần Redis cho các lời gọi này; điều đó không có nghĩa toàn bộ hệ thống không cần hạ tầng khác.
- Có thể thêm implementation cache khác và cấu hình cách lựa chọn mà không phải viết lại các điểm gọi trong nghiệp vụ.
- Tập trung TTL, serialization và xử lý lỗi Redis trong một implementation.

## Giới hạn

- Strategy được chọn lúc khởi động theo profile; NoOp không tự động được chọn khi Redis gặp lỗi.
- Implementation Redis hiện tự bắt lỗi và trả `null` khi đọc thất bại; đó là cache miss ở implementation đang dùng, không phải chuyển bean sang strategy khác.
- Mẫu Strategy giải quyết việc thay thế hành vi. Luồng đọc cache rồi truy vấn database khi miss là **cache-aside**, một khía cạnh khác của thiết kế cache.

## Sơ đồ

[Mở Strategy.drawio](Strategy.drawio): trang **Cấu trúc Strategy** mô tả interface, hai implementation, context và lựa chọn theo profile.
